-- Copyright (C) 2025  Altera Corporation. All rights reserved.
-- Your use of Altera Corporation's design tools, logic functions 
-- and other software and tools, and any partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Altera Program License 
-- Subscription Agreement, the Altera Quartus Prime License Agreement,
-- the Altera IP License Agreement, or other applicable license
-- agreement, including, without limitation, that your use is for
-- the sole purpose of programming logic devices manufactured by
-- Altera and sold by Altera or its authorized distributors.  Please
-- refer to the Altera Software License Subscription Agreements 
-- on the Quartus Prime software download page.

-- VENDOR "Altera"
-- PROGRAM "Quartus Prime"
-- VERSION "Version 25.1std.0 Build 1129 10/21/2025 SC Lite Edition"

-- DATE "10/22/2026 22:11:53"

-- 
-- Device: Altera 10M50DAF484C7G Package FBGA484
-- 

-- 
-- This VHDL file should be used for Questa Altera FPGA (VHDL) only
-- 

LIBRARY FIFTYFIVENM;
LIBRARY IEEE;
USE FIFTYFIVENM.FIFTYFIVENM_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	hard_block IS
    PORT (
	devoe : IN std_logic;
	devclrn : IN std_logic;
	devpor : IN std_logic
	);
END hard_block;

-- Design Ports Information
-- ~ALTERA_TMS~	=>  Location: PIN_H2,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_TCK~	=>  Location: PIN_G2,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_TDI~	=>  Location: PIN_L4,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_TDO~	=>  Location: PIN_M5,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ~ALTERA_CONFIG_SEL~	=>  Location: PIN_H10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ~ALTERA_nCONFIG~	=>  Location: PIN_H9,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_nSTATUS~	=>  Location: PIN_G9,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_CONF_DONE~	=>  Location: PIN_F8,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default


ARCHITECTURE structure OF hard_block IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL \~ALTERA_TMS~~padout\ : std_logic;
SIGNAL \~ALTERA_TCK~~padout\ : std_logic;
SIGNAL \~ALTERA_TDI~~padout\ : std_logic;
SIGNAL \~ALTERA_CONFIG_SEL~~padout\ : std_logic;
SIGNAL \~ALTERA_nCONFIG~~padout\ : std_logic;
SIGNAL \~ALTERA_nSTATUS~~padout\ : std_logic;
SIGNAL \~ALTERA_CONF_DONE~~padout\ : std_logic;
SIGNAL \~ALTERA_TMS~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_TCK~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_TDI~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_CONFIG_SEL~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_nCONFIG~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_nSTATUS~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_CONF_DONE~~ibuf_o\ : std_logic;

BEGIN

ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;
END structure;


LIBRARY ALTERA;
LIBRARY FIFTYFIVENM;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE FIFTYFIVENM.FIFTYFIVENM_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	top IS
    PORT (
	MAX10_CLK1_50 : IN std_logic;
	KEY : IN std_logic_vector(1 DOWNTO 0);
	LEDR : BUFFER std_logic_vector(9 DOWNTO 0)
	);
END top;

-- Design Ports Information
-- KEY[1]	=>  Location: PIN_A7,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: Default
-- LEDR[0]	=>  Location: PIN_A8,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 8mA
-- LEDR[1]	=>  Location: PIN_A9,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 8mA
-- LEDR[2]	=>  Location: PIN_A10,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 8mA
-- LEDR[3]	=>  Location: PIN_B10,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 8mA
-- LEDR[4]	=>  Location: PIN_D13,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 8mA
-- LEDR[5]	=>  Location: PIN_C13,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 8mA
-- LEDR[6]	=>  Location: PIN_E14,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 8mA
-- LEDR[7]	=>  Location: PIN_D14,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 8mA
-- LEDR[8]	=>  Location: PIN_A11,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 8mA
-- LEDR[9]	=>  Location: PIN_B11,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 8mA
-- KEY[0]	=>  Location: PIN_B8,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: Default
-- MAX10_CLK1_50	=>  Location: PIN_P11,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: Default


ARCHITECTURE structure OF top IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_MAX10_CLK1_50 : std_logic;
SIGNAL ww_KEY : std_logic_vector(1 DOWNTO 0);
SIGNAL ww_LEDR : std_logic_vector(9 DOWNTO 0);
SIGNAL \~QUARTUS_CREATED_ADC1~_CHSEL_bus\ : std_logic_vector(4 DOWNTO 0);
SIGNAL \~QUARTUS_CREATED_ADC2~_CHSEL_bus\ : std_logic_vector(4 DOWNTO 0);
SIGNAL \MAX10_CLK1_50~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \KEY[1]~input_o\ : std_logic;
SIGNAL \~QUARTUS_CREATED_GND~I_combout\ : std_logic;
SIGNAL \~QUARTUS_CREATED_UNVM~~busy\ : std_logic;
SIGNAL \~QUARTUS_CREATED_ADC1~~eoc\ : std_logic;
SIGNAL \~QUARTUS_CREATED_ADC2~~eoc\ : std_logic;
SIGNAL \LEDR[0]~output_o\ : std_logic;
SIGNAL \LEDR[1]~output_o\ : std_logic;
SIGNAL \LEDR[2]~output_o\ : std_logic;
SIGNAL \LEDR[3]~output_o\ : std_logic;
SIGNAL \LEDR[4]~output_o\ : std_logic;
SIGNAL \LEDR[5]~output_o\ : std_logic;
SIGNAL \LEDR[6]~output_o\ : std_logic;
SIGNAL \LEDR[7]~output_o\ : std_logic;
SIGNAL \LEDR[8]~output_o\ : std_logic;
SIGNAL \LEDR[9]~output_o\ : std_logic;
SIGNAL \MAX10_CLK1_50~input_o\ : std_logic;
SIGNAL \MAX10_CLK1_50~inputclkctrl_outclk\ : std_logic;
SIGNAL \KEY[0]~input_o\ : std_logic;
SIGNAL \u_tick|count_i~0_combout\ : std_logic;
SIGNAL \u_tick|period_count[0]~26_combout\ : std_logic;
SIGNAL \u_tick|period_count[0]~27\ : std_logic;
SIGNAL \u_tick|period_count[1]~28_combout\ : std_logic;
SIGNAL \u_tick|period_count[1]~29\ : std_logic;
SIGNAL \u_tick|period_count[2]~30_combout\ : std_logic;
SIGNAL \u_tick|period_count[2]~31\ : std_logic;
SIGNAL \u_tick|period_count[3]~32_combout\ : std_logic;
SIGNAL \u_tick|period_count[3]~33\ : std_logic;
SIGNAL \u_tick|period_count[4]~34_combout\ : std_logic;
SIGNAL \u_tick|period_count[4]~35\ : std_logic;
SIGNAL \u_tick|period_count[5]~36_combout\ : std_logic;
SIGNAL \u_tick|period_count[5]~37\ : std_logic;
SIGNAL \u_tick|period_count[6]~38_combout\ : std_logic;
SIGNAL \u_tick|period_count[6]~39\ : std_logic;
SIGNAL \u_tick|period_count[7]~40_combout\ : std_logic;
SIGNAL \u_tick|period_count[7]~41\ : std_logic;
SIGNAL \u_tick|period_count[8]~42_combout\ : std_logic;
SIGNAL \u_tick|period_count[8]~43\ : std_logic;
SIGNAL \u_tick|period_count[9]~44_combout\ : std_logic;
SIGNAL \u_tick|period_count[9]~45\ : std_logic;
SIGNAL \u_tick|period_count[10]~46_combout\ : std_logic;
SIGNAL \u_tick|period_count[10]~47\ : std_logic;
SIGNAL \u_tick|period_count[11]~48_combout\ : std_logic;
SIGNAL \u_tick|period_count[11]~49\ : std_logic;
SIGNAL \u_tick|period_count[12]~50_combout\ : std_logic;
SIGNAL \u_tick|period_count[12]~51\ : std_logic;
SIGNAL \u_tick|period_count[13]~52_combout\ : std_logic;
SIGNAL \u_tick|period_count[13]~53\ : std_logic;
SIGNAL \u_tick|period_count[14]~54_combout\ : std_logic;
SIGNAL \u_tick|period_count[14]~55\ : std_logic;
SIGNAL \u_tick|period_count[15]~56_combout\ : std_logic;
SIGNAL \u_tick|period_count[15]~57\ : std_logic;
SIGNAL \u_tick|period_count[16]~58_combout\ : std_logic;
SIGNAL \u_tick|period_count[16]~59\ : std_logic;
SIGNAL \u_tick|period_count[17]~60_combout\ : std_logic;
SIGNAL \u_tick|period_count[17]~61\ : std_logic;
SIGNAL \u_tick|period_count[18]~62_combout\ : std_logic;
SIGNAL \u_tick|period_count[18]~63\ : std_logic;
SIGNAL \u_tick|period_count[19]~64_combout\ : std_logic;
SIGNAL \u_tick|period_count[19]~65\ : std_logic;
SIGNAL \u_tick|period_count[20]~66_combout\ : std_logic;
SIGNAL \u_tick|period_count[20]~67\ : std_logic;
SIGNAL \u_tick|period_count[21]~68_combout\ : std_logic;
SIGNAL \u_tick|period_count[21]~69\ : std_logic;
SIGNAL \u_tick|period_count[22]~70_combout\ : std_logic;
SIGNAL \u_tick|period_count[22]~71\ : std_logic;
SIGNAL \u_tick|period_count[23]~72_combout\ : std_logic;
SIGNAL \u_tick|period_count[23]~73\ : std_logic;
SIGNAL \u_tick|period_count[24]~74_combout\ : std_logic;
SIGNAL \u_tick|period_count[24]~75\ : std_logic;
SIGNAL \u_tick|period_count[25]~76_combout\ : std_logic;
SIGNAL \u_tick|Equal0~5_combout\ : std_logic;
SIGNAL \u_tick|Equal0~6_combout\ : std_logic;
SIGNAL \u_tick|Equal0~7_combout\ : std_logic;
SIGNAL \u_tick|Equal0~3_combout\ : std_logic;
SIGNAL \u_tick|Equal0~0_combout\ : std_logic;
SIGNAL \u_tick|Equal0~1_combout\ : std_logic;
SIGNAL \u_tick|Equal0~2_combout\ : std_logic;
SIGNAL \u_tick|Equal0~4_combout\ : std_logic;
SIGNAL \u_tick|count_i[0]~1_combout\ : std_logic;
SIGNAL \u_tick|count_i~2_combout\ : std_logic;
SIGNAL \u_tick|count_i~3_combout\ : std_logic;
SIGNAL \u_tick|Add0~0_combout\ : std_logic;
SIGNAL \u_tick|count_i~4_combout\ : std_logic;
SIGNAL \u_tick|period_count\ : std_logic_vector(25 DOWNTO 0);
SIGNAL \u_tick|count_i\ : std_logic_vector(3 DOWNTO 0);

COMPONENT hard_block
    PORT (
	devoe : IN std_logic;
	devclrn : IN std_logic;
	devpor : IN std_logic);
END COMPONENT;

BEGIN

ww_MAX10_CLK1_50 <= MAX10_CLK1_50;
ww_KEY <= KEY;
LEDR <= ww_LEDR;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\~QUARTUS_CREATED_ADC1~_CHSEL_bus\ <= (\~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\);

\~QUARTUS_CREATED_ADC2~_CHSEL_bus\ <= (\~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\);

\MAX10_CLK1_50~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \MAX10_CLK1_50~input_o\);
auto_generated_inst : hard_block
PORT MAP (
	devoe => ww_devoe,
	devclrn => ww_devclrn,
	devpor => ww_devpor);

-- Location: LCCOMB_X44_Y41_N24
\~QUARTUS_CREATED_GND~I\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \~QUARTUS_CREATED_GND~I_combout\ = GND

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	combout => \~QUARTUS_CREATED_GND~I_combout\);

-- Location: IOOBUF_X46_Y54_N2
\LEDR[0]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \u_tick|count_i\(0),
	devoe => ww_devoe,
	o => \LEDR[0]~output_o\);

-- Location: IOOBUF_X46_Y54_N23
\LEDR[1]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \u_tick|count_i\(1),
	devoe => ww_devoe,
	o => \LEDR[1]~output_o\);

-- Location: IOOBUF_X51_Y54_N16
\LEDR[2]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \u_tick|count_i\(2),
	devoe => ww_devoe,
	o => \LEDR[2]~output_o\);

-- Location: IOOBUF_X46_Y54_N9
\LEDR[3]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \u_tick|count_i\(3),
	devoe => ww_devoe,
	o => \LEDR[3]~output_o\);

-- Location: IOOBUF_X56_Y54_N30
\LEDR[4]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => \LEDR[4]~output_o\);

-- Location: IOOBUF_X58_Y54_N23
\LEDR[5]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => \LEDR[5]~output_o\);

-- Location: IOOBUF_X66_Y54_N23
\LEDR[6]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => \LEDR[6]~output_o\);

-- Location: IOOBUF_X56_Y54_N9
\LEDR[7]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => \LEDR[7]~output_o\);

-- Location: IOOBUF_X51_Y54_N9
\LEDR[8]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => \LEDR[8]~output_o\);

-- Location: IOOBUF_X49_Y54_N9
\LEDR[9]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => \LEDR[9]~output_o\);

-- Location: IOIBUF_X34_Y0_N29
\MAX10_CLK1_50~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_MAX10_CLK1_50,
	o => \MAX10_CLK1_50~input_o\);

-- Location: CLKCTRL_G19
\MAX10_CLK1_50~inputclkctrl\ : fiftyfivenm_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \MAX10_CLK1_50~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \MAX10_CLK1_50~inputclkctrl_outclk\);

-- Location: IOIBUF_X46_Y54_N29
\KEY[0]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_KEY(0),
	o => \KEY[0]~input_o\);

-- Location: LCCOMB_X49_Y50_N22
\u_tick|count_i~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \u_tick|count_i~0_combout\ = (\KEY[0]~input_o\ & !\u_tick|count_i\(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \KEY[0]~input_o\,
	datac => \u_tick|count_i\(0),
	combout => \u_tick|count_i~0_combout\);

-- Location: LCCOMB_X50_Y51_N6
\u_tick|period_count[0]~26\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \u_tick|period_count[0]~26_combout\ = \u_tick|period_count\(0) $ (VCC)
-- \u_tick|period_count[0]~27\ = CARRY(\u_tick|period_count\(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_tick|period_count\(0),
	datad => VCC,
	combout => \u_tick|period_count[0]~26_combout\,
	cout => \u_tick|period_count[0]~27\);

-- Location: FF_X50_Y51_N7
\u_tick|period_count[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \MAX10_CLK1_50~inputclkctrl_outclk\,
	d => \u_tick|period_count[0]~26_combout\,
	sclr => \u_tick|count_i[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_tick|period_count\(0));

-- Location: LCCOMB_X50_Y51_N8
\u_tick|period_count[1]~28\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \u_tick|period_count[1]~28_combout\ = (\u_tick|period_count\(1) & (!\u_tick|period_count[0]~27\)) # (!\u_tick|period_count\(1) & ((\u_tick|period_count[0]~27\) # (GND)))
-- \u_tick|period_count[1]~29\ = CARRY((!\u_tick|period_count[0]~27\) # (!\u_tick|period_count\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_tick|period_count\(1),
	datad => VCC,
	cin => \u_tick|period_count[0]~27\,
	combout => \u_tick|period_count[1]~28_combout\,
	cout => \u_tick|period_count[1]~29\);

-- Location: FF_X50_Y51_N9
\u_tick|period_count[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \MAX10_CLK1_50~inputclkctrl_outclk\,
	d => \u_tick|period_count[1]~28_combout\,
	sclr => \u_tick|count_i[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_tick|period_count\(1));

-- Location: LCCOMB_X50_Y51_N10
\u_tick|period_count[2]~30\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \u_tick|period_count[2]~30_combout\ = (\u_tick|period_count\(2) & (\u_tick|period_count[1]~29\ $ (GND))) # (!\u_tick|period_count\(2) & (!\u_tick|period_count[1]~29\ & VCC))
-- \u_tick|period_count[2]~31\ = CARRY((\u_tick|period_count\(2) & !\u_tick|period_count[1]~29\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_tick|period_count\(2),
	datad => VCC,
	cin => \u_tick|period_count[1]~29\,
	combout => \u_tick|period_count[2]~30_combout\,
	cout => \u_tick|period_count[2]~31\);

-- Location: FF_X50_Y51_N11
\u_tick|period_count[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \MAX10_CLK1_50~inputclkctrl_outclk\,
	d => \u_tick|period_count[2]~30_combout\,
	sclr => \u_tick|count_i[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_tick|period_count\(2));

-- Location: LCCOMB_X50_Y51_N12
\u_tick|period_count[3]~32\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \u_tick|period_count[3]~32_combout\ = (\u_tick|period_count\(3) & (!\u_tick|period_count[2]~31\)) # (!\u_tick|period_count\(3) & ((\u_tick|period_count[2]~31\) # (GND)))
-- \u_tick|period_count[3]~33\ = CARRY((!\u_tick|period_count[2]~31\) # (!\u_tick|period_count\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_tick|period_count\(3),
	datad => VCC,
	cin => \u_tick|period_count[2]~31\,
	combout => \u_tick|period_count[3]~32_combout\,
	cout => \u_tick|period_count[3]~33\);

-- Location: FF_X50_Y51_N13
\u_tick|period_count[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \MAX10_CLK1_50~inputclkctrl_outclk\,
	d => \u_tick|period_count[3]~32_combout\,
	sclr => \u_tick|count_i[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_tick|period_count\(3));

-- Location: LCCOMB_X50_Y51_N14
\u_tick|period_count[4]~34\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \u_tick|period_count[4]~34_combout\ = (\u_tick|period_count\(4) & (\u_tick|period_count[3]~33\ $ (GND))) # (!\u_tick|period_count\(4) & (!\u_tick|period_count[3]~33\ & VCC))
-- \u_tick|period_count[4]~35\ = CARRY((\u_tick|period_count\(4) & !\u_tick|period_count[3]~33\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_tick|period_count\(4),
	datad => VCC,
	cin => \u_tick|period_count[3]~33\,
	combout => \u_tick|period_count[4]~34_combout\,
	cout => \u_tick|period_count[4]~35\);

-- Location: FF_X50_Y51_N15
\u_tick|period_count[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \MAX10_CLK1_50~inputclkctrl_outclk\,
	d => \u_tick|period_count[4]~34_combout\,
	sclr => \u_tick|count_i[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_tick|period_count\(4));

-- Location: LCCOMB_X50_Y51_N16
\u_tick|period_count[5]~36\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \u_tick|period_count[5]~36_combout\ = (\u_tick|period_count\(5) & (!\u_tick|period_count[4]~35\)) # (!\u_tick|period_count\(5) & ((\u_tick|period_count[4]~35\) # (GND)))
-- \u_tick|period_count[5]~37\ = CARRY((!\u_tick|period_count[4]~35\) # (!\u_tick|period_count\(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_tick|period_count\(5),
	datad => VCC,
	cin => \u_tick|period_count[4]~35\,
	combout => \u_tick|period_count[5]~36_combout\,
	cout => \u_tick|period_count[5]~37\);

-- Location: FF_X50_Y51_N17
\u_tick|period_count[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \MAX10_CLK1_50~inputclkctrl_outclk\,
	d => \u_tick|period_count[5]~36_combout\,
	sclr => \u_tick|count_i[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_tick|period_count\(5));

-- Location: LCCOMB_X50_Y51_N18
\u_tick|period_count[6]~38\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \u_tick|period_count[6]~38_combout\ = (\u_tick|period_count\(6) & (\u_tick|period_count[5]~37\ $ (GND))) # (!\u_tick|period_count\(6) & (!\u_tick|period_count[5]~37\ & VCC))
-- \u_tick|period_count[6]~39\ = CARRY((\u_tick|period_count\(6) & !\u_tick|period_count[5]~37\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_tick|period_count\(6),
	datad => VCC,
	cin => \u_tick|period_count[5]~37\,
	combout => \u_tick|period_count[6]~38_combout\,
	cout => \u_tick|period_count[6]~39\);

-- Location: FF_X50_Y51_N19
\u_tick|period_count[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \MAX10_CLK1_50~inputclkctrl_outclk\,
	d => \u_tick|period_count[6]~38_combout\,
	sclr => \u_tick|count_i[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_tick|period_count\(6));

-- Location: LCCOMB_X50_Y51_N20
\u_tick|period_count[7]~40\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \u_tick|period_count[7]~40_combout\ = (\u_tick|period_count\(7) & (!\u_tick|period_count[6]~39\)) # (!\u_tick|period_count\(7) & ((\u_tick|period_count[6]~39\) # (GND)))
-- \u_tick|period_count[7]~41\ = CARRY((!\u_tick|period_count[6]~39\) # (!\u_tick|period_count\(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_tick|period_count\(7),
	datad => VCC,
	cin => \u_tick|period_count[6]~39\,
	combout => \u_tick|period_count[7]~40_combout\,
	cout => \u_tick|period_count[7]~41\);

-- Location: FF_X50_Y51_N21
\u_tick|period_count[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \MAX10_CLK1_50~inputclkctrl_outclk\,
	d => \u_tick|period_count[7]~40_combout\,
	sclr => \u_tick|count_i[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_tick|period_count\(7));

-- Location: LCCOMB_X50_Y51_N22
\u_tick|period_count[8]~42\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \u_tick|period_count[8]~42_combout\ = (\u_tick|period_count\(8) & (\u_tick|period_count[7]~41\ $ (GND))) # (!\u_tick|period_count\(8) & (!\u_tick|period_count[7]~41\ & VCC))
-- \u_tick|period_count[8]~43\ = CARRY((\u_tick|period_count\(8) & !\u_tick|period_count[7]~41\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_tick|period_count\(8),
	datad => VCC,
	cin => \u_tick|period_count[7]~41\,
	combout => \u_tick|period_count[8]~42_combout\,
	cout => \u_tick|period_count[8]~43\);

-- Location: FF_X50_Y51_N23
\u_tick|period_count[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \MAX10_CLK1_50~inputclkctrl_outclk\,
	d => \u_tick|period_count[8]~42_combout\,
	sclr => \u_tick|count_i[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_tick|period_count\(8));

-- Location: LCCOMB_X50_Y51_N24
\u_tick|period_count[9]~44\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \u_tick|period_count[9]~44_combout\ = (\u_tick|period_count\(9) & (!\u_tick|period_count[8]~43\)) # (!\u_tick|period_count\(9) & ((\u_tick|period_count[8]~43\) # (GND)))
-- \u_tick|period_count[9]~45\ = CARRY((!\u_tick|period_count[8]~43\) # (!\u_tick|period_count\(9)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_tick|period_count\(9),
	datad => VCC,
	cin => \u_tick|period_count[8]~43\,
	combout => \u_tick|period_count[9]~44_combout\,
	cout => \u_tick|period_count[9]~45\);

-- Location: FF_X50_Y51_N25
\u_tick|period_count[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \MAX10_CLK1_50~inputclkctrl_outclk\,
	d => \u_tick|period_count[9]~44_combout\,
	sclr => \u_tick|count_i[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_tick|period_count\(9));

-- Location: LCCOMB_X50_Y51_N26
\u_tick|period_count[10]~46\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \u_tick|period_count[10]~46_combout\ = (\u_tick|period_count\(10) & (\u_tick|period_count[9]~45\ $ (GND))) # (!\u_tick|period_count\(10) & (!\u_tick|period_count[9]~45\ & VCC))
-- \u_tick|period_count[10]~47\ = CARRY((\u_tick|period_count\(10) & !\u_tick|period_count[9]~45\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_tick|period_count\(10),
	datad => VCC,
	cin => \u_tick|period_count[9]~45\,
	combout => \u_tick|period_count[10]~46_combout\,
	cout => \u_tick|period_count[10]~47\);

-- Location: FF_X50_Y51_N27
\u_tick|period_count[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \MAX10_CLK1_50~inputclkctrl_outclk\,
	d => \u_tick|period_count[10]~46_combout\,
	sclr => \u_tick|count_i[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_tick|period_count\(10));

-- Location: LCCOMB_X50_Y51_N28
\u_tick|period_count[11]~48\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \u_tick|period_count[11]~48_combout\ = (\u_tick|period_count\(11) & (!\u_tick|period_count[10]~47\)) # (!\u_tick|period_count\(11) & ((\u_tick|period_count[10]~47\) # (GND)))
-- \u_tick|period_count[11]~49\ = CARRY((!\u_tick|period_count[10]~47\) # (!\u_tick|period_count\(11)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_tick|period_count\(11),
	datad => VCC,
	cin => \u_tick|period_count[10]~47\,
	combout => \u_tick|period_count[11]~48_combout\,
	cout => \u_tick|period_count[11]~49\);

-- Location: FF_X50_Y51_N29
\u_tick|period_count[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \MAX10_CLK1_50~inputclkctrl_outclk\,
	d => \u_tick|period_count[11]~48_combout\,
	sclr => \u_tick|count_i[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_tick|period_count\(11));

-- Location: LCCOMB_X50_Y51_N30
\u_tick|period_count[12]~50\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \u_tick|period_count[12]~50_combout\ = (\u_tick|period_count\(12) & (\u_tick|period_count[11]~49\ $ (GND))) # (!\u_tick|period_count\(12) & (!\u_tick|period_count[11]~49\ & VCC))
-- \u_tick|period_count[12]~51\ = CARRY((\u_tick|period_count\(12) & !\u_tick|period_count[11]~49\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_tick|period_count\(12),
	datad => VCC,
	cin => \u_tick|period_count[11]~49\,
	combout => \u_tick|period_count[12]~50_combout\,
	cout => \u_tick|period_count[12]~51\);

-- Location: FF_X49_Y50_N13
\u_tick|period_count[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \MAX10_CLK1_50~inputclkctrl_outclk\,
	asdata => \u_tick|period_count[12]~50_combout\,
	sclr => \u_tick|count_i[0]~1_combout\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_tick|period_count\(12));

-- Location: LCCOMB_X50_Y50_N0
\u_tick|period_count[13]~52\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \u_tick|period_count[13]~52_combout\ = (\u_tick|period_count\(13) & (!\u_tick|period_count[12]~51\)) # (!\u_tick|period_count\(13) & ((\u_tick|period_count[12]~51\) # (GND)))
-- \u_tick|period_count[13]~53\ = CARRY((!\u_tick|period_count[12]~51\) # (!\u_tick|period_count\(13)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_tick|period_count\(13),
	datad => VCC,
	cin => \u_tick|period_count[12]~51\,
	combout => \u_tick|period_count[13]~52_combout\,
	cout => \u_tick|period_count[13]~53\);

-- Location: FF_X50_Y50_N1
\u_tick|period_count[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \MAX10_CLK1_50~inputclkctrl_outclk\,
	d => \u_tick|period_count[13]~52_combout\,
	sclr => \u_tick|count_i[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_tick|period_count\(13));

-- Location: LCCOMB_X50_Y50_N2
\u_tick|period_count[14]~54\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \u_tick|period_count[14]~54_combout\ = (\u_tick|period_count\(14) & (\u_tick|period_count[13]~53\ $ (GND))) # (!\u_tick|period_count\(14) & (!\u_tick|period_count[13]~53\ & VCC))
-- \u_tick|period_count[14]~55\ = CARRY((\u_tick|period_count\(14) & !\u_tick|period_count[13]~53\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_tick|period_count\(14),
	datad => VCC,
	cin => \u_tick|period_count[13]~53\,
	combout => \u_tick|period_count[14]~54_combout\,
	cout => \u_tick|period_count[14]~55\);

-- Location: FF_X50_Y50_N3
\u_tick|period_count[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \MAX10_CLK1_50~inputclkctrl_outclk\,
	d => \u_tick|period_count[14]~54_combout\,
	sclr => \u_tick|count_i[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_tick|period_count\(14));

-- Location: LCCOMB_X50_Y50_N4
\u_tick|period_count[15]~56\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \u_tick|period_count[15]~56_combout\ = (\u_tick|period_count\(15) & (!\u_tick|period_count[14]~55\)) # (!\u_tick|period_count\(15) & ((\u_tick|period_count[14]~55\) # (GND)))
-- \u_tick|period_count[15]~57\ = CARRY((!\u_tick|period_count[14]~55\) # (!\u_tick|period_count\(15)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_tick|period_count\(15),
	datad => VCC,
	cin => \u_tick|period_count[14]~55\,
	combout => \u_tick|period_count[15]~56_combout\,
	cout => \u_tick|period_count[15]~57\);

-- Location: FF_X50_Y50_N5
\u_tick|period_count[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \MAX10_CLK1_50~inputclkctrl_outclk\,
	d => \u_tick|period_count[15]~56_combout\,
	sclr => \u_tick|count_i[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_tick|period_count\(15));

-- Location: LCCOMB_X50_Y50_N6
\u_tick|period_count[16]~58\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \u_tick|period_count[16]~58_combout\ = (\u_tick|period_count\(16) & (\u_tick|period_count[15]~57\ $ (GND))) # (!\u_tick|period_count\(16) & (!\u_tick|period_count[15]~57\ & VCC))
-- \u_tick|period_count[16]~59\ = CARRY((\u_tick|period_count\(16) & !\u_tick|period_count[15]~57\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_tick|period_count\(16),
	datad => VCC,
	cin => \u_tick|period_count[15]~57\,
	combout => \u_tick|period_count[16]~58_combout\,
	cout => \u_tick|period_count[16]~59\);

-- Location: FF_X50_Y50_N7
\u_tick|period_count[16]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \MAX10_CLK1_50~inputclkctrl_outclk\,
	d => \u_tick|period_count[16]~58_combout\,
	sclr => \u_tick|count_i[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_tick|period_count\(16));

-- Location: LCCOMB_X50_Y50_N8
\u_tick|period_count[17]~60\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \u_tick|period_count[17]~60_combout\ = (\u_tick|period_count\(17) & (!\u_tick|period_count[16]~59\)) # (!\u_tick|period_count\(17) & ((\u_tick|period_count[16]~59\) # (GND)))
-- \u_tick|period_count[17]~61\ = CARRY((!\u_tick|period_count[16]~59\) # (!\u_tick|period_count\(17)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_tick|period_count\(17),
	datad => VCC,
	cin => \u_tick|period_count[16]~59\,
	combout => \u_tick|period_count[17]~60_combout\,
	cout => \u_tick|period_count[17]~61\);

-- Location: FF_X50_Y50_N9
\u_tick|period_count[17]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \MAX10_CLK1_50~inputclkctrl_outclk\,
	d => \u_tick|period_count[17]~60_combout\,
	sclr => \u_tick|count_i[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_tick|period_count\(17));

-- Location: LCCOMB_X50_Y50_N10
\u_tick|period_count[18]~62\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \u_tick|period_count[18]~62_combout\ = (\u_tick|period_count\(18) & (\u_tick|period_count[17]~61\ $ (GND))) # (!\u_tick|period_count\(18) & (!\u_tick|period_count[17]~61\ & VCC))
-- \u_tick|period_count[18]~63\ = CARRY((\u_tick|period_count\(18) & !\u_tick|period_count[17]~61\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_tick|period_count\(18),
	datad => VCC,
	cin => \u_tick|period_count[17]~61\,
	combout => \u_tick|period_count[18]~62_combout\,
	cout => \u_tick|period_count[18]~63\);

-- Location: FF_X50_Y50_N11
\u_tick|period_count[18]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \MAX10_CLK1_50~inputclkctrl_outclk\,
	d => \u_tick|period_count[18]~62_combout\,
	sclr => \u_tick|count_i[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_tick|period_count\(18));

-- Location: LCCOMB_X50_Y50_N12
\u_tick|period_count[19]~64\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \u_tick|period_count[19]~64_combout\ = (\u_tick|period_count\(19) & (!\u_tick|period_count[18]~63\)) # (!\u_tick|period_count\(19) & ((\u_tick|period_count[18]~63\) # (GND)))
-- \u_tick|period_count[19]~65\ = CARRY((!\u_tick|period_count[18]~63\) # (!\u_tick|period_count\(19)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_tick|period_count\(19),
	datad => VCC,
	cin => \u_tick|period_count[18]~63\,
	combout => \u_tick|period_count[19]~64_combout\,
	cout => \u_tick|period_count[19]~65\);

-- Location: FF_X50_Y50_N13
\u_tick|period_count[19]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \MAX10_CLK1_50~inputclkctrl_outclk\,
	d => \u_tick|period_count[19]~64_combout\,
	sclr => \u_tick|count_i[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_tick|period_count\(19));

-- Location: LCCOMB_X50_Y50_N14
\u_tick|period_count[20]~66\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \u_tick|period_count[20]~66_combout\ = (\u_tick|period_count\(20) & (\u_tick|period_count[19]~65\ $ (GND))) # (!\u_tick|period_count\(20) & (!\u_tick|period_count[19]~65\ & VCC))
-- \u_tick|period_count[20]~67\ = CARRY((\u_tick|period_count\(20) & !\u_tick|period_count[19]~65\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_tick|period_count\(20),
	datad => VCC,
	cin => \u_tick|period_count[19]~65\,
	combout => \u_tick|period_count[20]~66_combout\,
	cout => \u_tick|period_count[20]~67\);

-- Location: FF_X50_Y50_N15
\u_tick|period_count[20]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \MAX10_CLK1_50~inputclkctrl_outclk\,
	d => \u_tick|period_count[20]~66_combout\,
	sclr => \u_tick|count_i[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_tick|period_count\(20));

-- Location: LCCOMB_X50_Y50_N16
\u_tick|period_count[21]~68\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \u_tick|period_count[21]~68_combout\ = (\u_tick|period_count\(21) & (!\u_tick|period_count[20]~67\)) # (!\u_tick|period_count\(21) & ((\u_tick|period_count[20]~67\) # (GND)))
-- \u_tick|period_count[21]~69\ = CARRY((!\u_tick|period_count[20]~67\) # (!\u_tick|period_count\(21)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_tick|period_count\(21),
	datad => VCC,
	cin => \u_tick|period_count[20]~67\,
	combout => \u_tick|period_count[21]~68_combout\,
	cout => \u_tick|period_count[21]~69\);

-- Location: FF_X50_Y50_N17
\u_tick|period_count[21]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \MAX10_CLK1_50~inputclkctrl_outclk\,
	d => \u_tick|period_count[21]~68_combout\,
	sclr => \u_tick|count_i[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_tick|period_count\(21));

-- Location: LCCOMB_X50_Y50_N18
\u_tick|period_count[22]~70\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \u_tick|period_count[22]~70_combout\ = (\u_tick|period_count\(22) & (\u_tick|period_count[21]~69\ $ (GND))) # (!\u_tick|period_count\(22) & (!\u_tick|period_count[21]~69\ & VCC))
-- \u_tick|period_count[22]~71\ = CARRY((\u_tick|period_count\(22) & !\u_tick|period_count[21]~69\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_tick|period_count\(22),
	datad => VCC,
	cin => \u_tick|period_count[21]~69\,
	combout => \u_tick|period_count[22]~70_combout\,
	cout => \u_tick|period_count[22]~71\);

-- Location: FF_X50_Y50_N19
\u_tick|period_count[22]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \MAX10_CLK1_50~inputclkctrl_outclk\,
	d => \u_tick|period_count[22]~70_combout\,
	sclr => \u_tick|count_i[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_tick|period_count\(22));

-- Location: LCCOMB_X50_Y50_N20
\u_tick|period_count[23]~72\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \u_tick|period_count[23]~72_combout\ = (\u_tick|period_count\(23) & (!\u_tick|period_count[22]~71\)) # (!\u_tick|period_count\(23) & ((\u_tick|period_count[22]~71\) # (GND)))
-- \u_tick|period_count[23]~73\ = CARRY((!\u_tick|period_count[22]~71\) # (!\u_tick|period_count\(23)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_tick|period_count\(23),
	datad => VCC,
	cin => \u_tick|period_count[22]~71\,
	combout => \u_tick|period_count[23]~72_combout\,
	cout => \u_tick|period_count[23]~73\);

-- Location: FF_X50_Y50_N21
\u_tick|period_count[23]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \MAX10_CLK1_50~inputclkctrl_outclk\,
	d => \u_tick|period_count[23]~72_combout\,
	sclr => \u_tick|count_i[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_tick|period_count\(23));

-- Location: LCCOMB_X50_Y50_N22
\u_tick|period_count[24]~74\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \u_tick|period_count[24]~74_combout\ = (\u_tick|period_count\(24) & (\u_tick|period_count[23]~73\ $ (GND))) # (!\u_tick|period_count\(24) & (!\u_tick|period_count[23]~73\ & VCC))
-- \u_tick|period_count[24]~75\ = CARRY((\u_tick|period_count\(24) & !\u_tick|period_count[23]~73\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_tick|period_count\(24),
	datad => VCC,
	cin => \u_tick|period_count[23]~73\,
	combout => \u_tick|period_count[24]~74_combout\,
	cout => \u_tick|period_count[24]~75\);

-- Location: FF_X50_Y50_N23
\u_tick|period_count[24]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \MAX10_CLK1_50~inputclkctrl_outclk\,
	d => \u_tick|period_count[24]~74_combout\,
	sclr => \u_tick|count_i[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_tick|period_count\(24));

-- Location: LCCOMB_X50_Y50_N24
\u_tick|period_count[25]~76\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \u_tick|period_count[25]~76_combout\ = \u_tick|period_count[24]~75\ $ (\u_tick|period_count\(25))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datad => \u_tick|period_count\(25),
	cin => \u_tick|period_count[24]~75\,
	combout => \u_tick|period_count[25]~76_combout\);

-- Location: FF_X50_Y50_N25
\u_tick|period_count[25]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \MAX10_CLK1_50~inputclkctrl_outclk\,
	d => \u_tick|period_count[25]~76_combout\,
	sclr => \u_tick|count_i[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_tick|period_count\(25));

-- Location: LCCOMB_X51_Y50_N8
\u_tick|Equal0~5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \u_tick|Equal0~5_combout\ = ((\u_tick|period_count\(16)) # ((\u_tick|period_count\(18)) # (!\u_tick|period_count\(19)))) # (!\u_tick|period_count\(17))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_tick|period_count\(17),
	datab => \u_tick|period_count\(16),
	datac => \u_tick|period_count\(18),
	datad => \u_tick|period_count\(19),
	combout => \u_tick|Equal0~5_combout\);

-- Location: LCCOMB_X51_Y50_N18
\u_tick|Equal0~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \u_tick|Equal0~6_combout\ = (((!\u_tick|period_count\(23)) # (!\u_tick|period_count\(21))) # (!\u_tick|period_count\(22))) # (!\u_tick|period_count\(20))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111111111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_tick|period_count\(20),
	datab => \u_tick|period_count\(22),
	datac => \u_tick|period_count\(21),
	datad => \u_tick|period_count\(23),
	combout => \u_tick|Equal0~6_combout\);

-- Location: LCCOMB_X51_Y50_N12
\u_tick|Equal0~7\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \u_tick|Equal0~7_combout\ = ((\u_tick|period_count\(24)) # ((\u_tick|Equal0~5_combout\) # (\u_tick|Equal0~6_combout\))) # (!\u_tick|period_count\(25))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_tick|period_count\(25),
	datab => \u_tick|period_count\(24),
	datac => \u_tick|Equal0~5_combout\,
	datad => \u_tick|Equal0~6_combout\,
	combout => \u_tick|Equal0~7_combout\);

-- Location: LCCOMB_X50_Y50_N30
\u_tick|Equal0~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \u_tick|Equal0~3_combout\ = (((!\u_tick|period_count\(14)) # (!\u_tick|period_count\(15))) # (!\u_tick|period_count\(13))) # (!\u_tick|period_count\(12))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111111111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_tick|period_count\(12),
	datab => \u_tick|period_count\(13),
	datac => \u_tick|period_count\(15),
	datad => \u_tick|period_count\(14),
	combout => \u_tick|Equal0~3_combout\);

-- Location: LCCOMB_X50_Y51_N0
\u_tick|Equal0~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \u_tick|Equal0~0_combout\ = (((!\u_tick|period_count\(3)) # (!\u_tick|period_count\(0))) # (!\u_tick|period_count\(1))) # (!\u_tick|period_count\(2))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111111111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_tick|period_count\(2),
	datab => \u_tick|period_count\(1),
	datac => \u_tick|period_count\(0),
	datad => \u_tick|period_count\(3),
	combout => \u_tick|Equal0~0_combout\);

-- Location: LCCOMB_X50_Y51_N2
\u_tick|Equal0~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \u_tick|Equal0~1_combout\ = (((\u_tick|period_count\(7)) # (!\u_tick|period_count\(6))) # (!\u_tick|period_count\(5))) # (!\u_tick|period_count\(4))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111101111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_tick|period_count\(4),
	datab => \u_tick|period_count\(5),
	datac => \u_tick|period_count\(6),
	datad => \u_tick|period_count\(7),
	combout => \u_tick|Equal0~1_combout\);

-- Location: LCCOMB_X50_Y51_N4
\u_tick|Equal0~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \u_tick|Equal0~2_combout\ = (\u_tick|period_count\(10)) # ((\u_tick|period_count\(11)) # ((\u_tick|period_count\(8)) # (\u_tick|period_count\(9))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_tick|period_count\(10),
	datab => \u_tick|period_count\(11),
	datac => \u_tick|period_count\(8),
	datad => \u_tick|period_count\(9),
	combout => \u_tick|Equal0~2_combout\);

-- Location: LCCOMB_X50_Y50_N28
\u_tick|Equal0~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \u_tick|Equal0~4_combout\ = (\u_tick|Equal0~3_combout\) # ((\u_tick|Equal0~0_combout\) # ((\u_tick|Equal0~1_combout\) # (\u_tick|Equal0~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_tick|Equal0~3_combout\,
	datab => \u_tick|Equal0~0_combout\,
	datac => \u_tick|Equal0~1_combout\,
	datad => \u_tick|Equal0~2_combout\,
	combout => \u_tick|Equal0~4_combout\);

-- Location: LCCOMB_X50_Y50_N26
\u_tick|count_i[0]~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \u_tick|count_i[0]~1_combout\ = ((!\u_tick|Equal0~7_combout\ & !\u_tick|Equal0~4_combout\)) # (!\KEY[0]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \KEY[0]~input_o\,
	datac => \u_tick|Equal0~7_combout\,
	datad => \u_tick|Equal0~4_combout\,
	combout => \u_tick|count_i[0]~1_combout\);

-- Location: FF_X49_Y50_N23
\u_tick|count_i[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \MAX10_CLK1_50~inputclkctrl_outclk\,
	d => \u_tick|count_i~0_combout\,
	ena => \u_tick|count_i[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_tick|count_i\(0));

-- Location: LCCOMB_X49_Y50_N24
\u_tick|count_i~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \u_tick|count_i~2_combout\ = (\KEY[0]~input_o\ & (\u_tick|count_i\(0) $ (\u_tick|count_i\(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100100001001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_tick|count_i\(0),
	datab => \KEY[0]~input_o\,
	datac => \u_tick|count_i\(1),
	combout => \u_tick|count_i~2_combout\);

-- Location: FF_X49_Y50_N25
\u_tick|count_i[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \MAX10_CLK1_50~inputclkctrl_outclk\,
	d => \u_tick|count_i~2_combout\,
	ena => \u_tick|count_i[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_tick|count_i\(1));

-- Location: LCCOMB_X49_Y50_N26
\u_tick|count_i~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \u_tick|count_i~3_combout\ = (\KEY[0]~input_o\ & (\u_tick|count_i\(2) $ (((\u_tick|count_i\(0) & \u_tick|count_i\(1))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100100011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_tick|count_i\(0),
	datab => \KEY[0]~input_o\,
	datac => \u_tick|count_i\(2),
	datad => \u_tick|count_i\(1),
	combout => \u_tick|count_i~3_combout\);

-- Location: FF_X49_Y50_N27
\u_tick|count_i[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \MAX10_CLK1_50~inputclkctrl_outclk\,
	d => \u_tick|count_i~3_combout\,
	ena => \u_tick|count_i[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_tick|count_i\(2));

-- Location: LCCOMB_X49_Y50_N30
\u_tick|Add0~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \u_tick|Add0~0_combout\ = \u_tick|count_i\(3) $ (((\u_tick|count_i\(0) & (\u_tick|count_i\(2) & \u_tick|count_i\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110110011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_tick|count_i\(0),
	datab => \u_tick|count_i\(3),
	datac => \u_tick|count_i\(2),
	datad => \u_tick|count_i\(1),
	combout => \u_tick|Add0~0_combout\);

-- Location: LCCOMB_X49_Y50_N28
\u_tick|count_i~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \u_tick|count_i~4_combout\ = (\u_tick|Add0~0_combout\ & \KEY[0]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_tick|Add0~0_combout\,
	datac => \KEY[0]~input_o\,
	combout => \u_tick|count_i~4_combout\);

-- Location: FF_X49_Y50_N29
\u_tick|count_i[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \MAX10_CLK1_50~inputclkctrl_outclk\,
	d => \u_tick|count_i~4_combout\,
	ena => \u_tick|count_i[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_tick|count_i\(3));

-- Location: IOIBUF_X49_Y54_N29
\KEY[1]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_KEY(1),
	o => \KEY[1]~input_o\);

-- Location: UNVM_X0_Y40_N40
\~QUARTUS_CREATED_UNVM~\ : fiftyfivenm_unvm
-- pragma translate_off
GENERIC MAP (
	addr_range1_end_addr => -1,
	addr_range1_offset => -1,
	addr_range2_end_addr => -1,
	addr_range2_offset => -1,
	addr_range3_offset => -1,
	is_compressed_image => "false",
	is_dual_boot => "false",
	is_eram_skip => "false",
	max_ufm_valid_addr => -1,
	max_valid_addr => -1,
	min_ufm_valid_addr => -1,
	min_valid_addr => -1,
	part_name => "quartus_created_unvm",
	reserve_block => "true")
-- pragma translate_on
PORT MAP (
	nosc_ena => \~QUARTUS_CREATED_GND~I_combout\,
	xe_ye => \~QUARTUS_CREATED_GND~I_combout\,
	se => \~QUARTUS_CREATED_GND~I_combout\,
	busy => \~QUARTUS_CREATED_UNVM~~busy\);

-- Location: ADCBLOCK_X43_Y52_N0
\~QUARTUS_CREATED_ADC1~\ : fiftyfivenm_adcblock
-- pragma translate_off
GENERIC MAP (
	analog_input_pin_mask => 0,
	clkdiv => 1,
	device_partname_fivechar_prefix => "none",
	is_this_first_or_second_adc => 1,
	prescalar => 0,
	pwd => 1,
	refsel => 0,
	reserve_block => "true",
	testbits => 66,
	tsclkdiv => 1,
	tsclksel => 0)
-- pragma translate_on
PORT MAP (
	soc => \~QUARTUS_CREATED_GND~I_combout\,
	usr_pwd => VCC,
	tsen => \~QUARTUS_CREATED_GND~I_combout\,
	chsel => \~QUARTUS_CREATED_ADC1~_CHSEL_bus\,
	eoc => \~QUARTUS_CREATED_ADC1~~eoc\);

-- Location: ADCBLOCK_X43_Y51_N0
\~QUARTUS_CREATED_ADC2~\ : fiftyfivenm_adcblock
-- pragma translate_off
GENERIC MAP (
	analog_input_pin_mask => 0,
	clkdiv => 1,
	device_partname_fivechar_prefix => "none",
	is_this_first_or_second_adc => 2,
	prescalar => 0,
	pwd => 1,
	refsel => 0,
	reserve_block => "true",
	testbits => 66,
	tsclkdiv => 1,
	tsclksel => 0)
-- pragma translate_on
PORT MAP (
	soc => \~QUARTUS_CREATED_GND~I_combout\,
	usr_pwd => VCC,
	tsen => \~QUARTUS_CREATED_GND~I_combout\,
	chsel => \~QUARTUS_CREATED_ADC2~_CHSEL_bus\,
	eoc => \~QUARTUS_CREATED_ADC2~~eoc\);

ww_LEDR(0) <= \LEDR[0]~output_o\;

ww_LEDR(1) <= \LEDR[1]~output_o\;

ww_LEDR(2) <= \LEDR[2]~output_o\;

ww_LEDR(3) <= \LEDR[3]~output_o\;

ww_LEDR(4) <= \LEDR[4]~output_o\;

ww_LEDR(5) <= \LEDR[5]~output_o\;

ww_LEDR(6) <= \LEDR[6]~output_o\;

ww_LEDR(7) <= \LEDR[7]~output_o\;

ww_LEDR(8) <= \LEDR[8]~output_o\;

ww_LEDR(9) <= \LEDR[9]~output_o\;
END structure;


